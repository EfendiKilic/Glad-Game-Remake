﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class PlayerControl : MonoBehaviour
{
    [SerializeField] private Rigidbody2D PlayerRb;
    [SerializeField] private float InputSpeed;
    [SerializeField] private float JumpPower;
    [SerializeField] private bool canDoubleJump;
    [SerializeField] private float DoubleJumpPower;
    [SerializeField] private GameObject WinPanel;
    [SerializeField] private GameObject LosePanel;
    [SerializeField] private Slider HealthSlider;
    [SerializeField] private int AddHealth;

    private Vector3 DefaultLocalScale;
    private Animator PlayerAnimator;

    public bool onGround;

    void Start()
    {
        PlayerRb = GetComponent<Rigidbody2D>();
        DefaultLocalScale = transform.localScale;
        PlayerAnimator = GetComponent<Animator>();
    }
    void Update()
    {
        Movement();
        Jump(); 
    }

    private void Movement()
    {
        #region Movement Input 
        float xSpeed = Input.GetAxis("Horizontal");
        PlayerAnimator.SetFloat("Speed", Mathf.Abs(xSpeed));
        PlayerRb.velocity = new Vector2(xSpeed * InputSpeed, PlayerRb.velocity.y);
        #endregion

        #region Player Turn In Direction
        if (xSpeed > 0)
        {
            transform.localScale = new Vector3(DefaultLocalScale.x, DefaultLocalScale.y, DefaultLocalScale.z);
        }
        else if(xSpeed < 0)
        {
            transform.localScale = new Vector3(-DefaultLocalScale.x, DefaultLocalScale.y, DefaultLocalScale.z);
        }
        #endregion
    }

    private void Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if(onGround == true)
            {
                PlayerRb.velocity = new Vector2(PlayerRb.velocity.x, JumpPower);
                PlayerAnimator.SetTrigger("Jump");
                canDoubleJump = true;
            }
            else
            {
                if(canDoubleJump == true)
                {
                    PlayerRb.velocity = new Vector2(PlayerRb.velocity.x, DoubleJumpPower);
                    canDoubleJump = false;
                    PlayerAnimator.SetTrigger("DoubleJump");
                }
            }
        }
    }

    public void PlayerAlive(int PlayerCurrentHealth)
    {
        if(PlayerCurrentHealth <= 0)
        {
            Die();
        }
    }

    #region Death Proceedings 
    private void Die()
    {
        PlayerAnimator.SetFloat("Speed", 0);
        PlayerAnimator.SetTrigger("Die");

        HealthSlider.value = 0;

        PlayerRb.constraints = RigidbodyConstraints2D.FreezeAll;
        enabled = false;
        StartCoroutine(Wait(false));
    }

    IEnumerator Wait(bool win)
    {
        yield return new WaitForSecondsRealtime(2f);
        Time.timeScale = 0;

        if(win == true)
        {
            WinPanel.SetActive(true);
        }
        else
        {
            LosePanel.SetActive(true);
        }
    }
    #endregion

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.layer == 9)
        {
            Die();
            
        }
        else if(collision.gameObject.layer == 12)
        {
            StartCoroutine(Wait(true));
            Destroy(collision.gameObject);
        }

        if(collision.gameObject.layer == 13)
        {
            Die();
        }

        if(collision.gameObject.layer == 14)
        {
            GetComponent<PlayerCombat>().AddHeal(AddHealth);
            Destroy(collision.gameObject);
        }

    }
}

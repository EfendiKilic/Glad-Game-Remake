﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PanelManager : MonoBehaviour
{
    [SerializeField] private GameObject FirstPanel;
    [SerializeField] private GameObject SecondPanel;
    [SerializeField] private GameObject ThirdPanel;
    [SerializeField] private GameObject ForthPanel;
    [SerializeField] private GameObject FifthPanel;
    [SerializeField] private GameObject SixthPanel;
    [SerializeField] private GameObject Buttons;


    #region first paner
    public void FirstPanelStarter()
    {
        FirstPanel.SetActive(true);
        Buttons.SetActive(false);
    }

    public void ComeBackFirstPanel()
    {
        FirstPanel.SetActive(false);
        Buttons.SetActive(true);
    }
    #endregion

    #region second panel
    public void SecondPanelStarter()
    {
        SecondPanel.SetActive(true);
        FirstPanel.SetActive(false);
    }

    public void ComeBackSecondPanel()
    {
        FirstPanel.SetActive(true);
        SecondPanel.SetActive(false);
    }
    #endregion

    #region third panel
    public void ThirdPanelStarter()
    {
        ThirdPanel.SetActive(true);
        SecondPanel.SetActive(false);
    }

    public void ComeBackThirdPanel()
    {
        SecondPanel.SetActive(true);
        ThirdPanel.SetActive(false);
    }
    #endregion

    #region forth panel
    public void ForthPanelStarter()
    {
        ForthPanel.SetActive(true);
        SecondPanel.SetActive(false);
    }

    public void ComeBackForthPanel()
    {
        SecondPanel.SetActive(true);
        ForthPanel.SetActive(false);
    }
    #endregion

    #region fifth panel
    public void FifthPanelStarter()
    {
        FifthPanel.SetActive(true);
        SecondPanel.SetActive(false);
    }

    public void ComeBackFifthPanel()
    {
        SecondPanel.SetActive(true);
        FifthPanel.SetActive(false);
    }
    #endregion

    #region sixth panel
    public void SixthPanelStarter()
    {
        SixthPanel.SetActive(true);
        FirstPanel.SetActive(false);
    }

    public void ComeBackSixthPanel()
    {
        FirstPanel.SetActive(true);
        SixthPanel.SetActive(false);
    }
    #endregion
}

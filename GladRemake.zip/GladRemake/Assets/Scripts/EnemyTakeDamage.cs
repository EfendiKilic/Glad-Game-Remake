﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTakeDamage : MonoBehaviour
{
    [SerializeField] private Animator EnemyAnimator;
    [SerializeField] private int MaxHealt = 100;
    int currentHealt;

    void Start()
    {
        currentHealt = MaxHealt;
    }

    public void TakeDamage(int damage)
    {
        currentHealt -= damage;
        EnemyAnimator.SetTrigger("TakeDamage");

        if(currentHealt <= 0)
        {
            EnemyDie();
        }
    }

    public void EnemyDie()
    {
        Debug.Log("Düşman öldü");

        GetComponent<Rigidbody2D>().gravityScale = 0;
        GetComponent<Collider2D>().enabled = false;

        EnemyAnimator.SetTrigger("Die");

        this.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0,0);
    }

   
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour
{
    Transform PlayerTransform;
    [SerializeField] private float Xmin;
    [SerializeField] private float Xmax;

    void Start()
    {
        PlayerTransform = GameObject.Find("Player").transform;
    }

    void Update()
    {
        transform.position = new Vector3(Mathf.Clamp(PlayerTransform.position.x, Xmin, Xmax), transform.position.y, transform.position.z);
    }
}

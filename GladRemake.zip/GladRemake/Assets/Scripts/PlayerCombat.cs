﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCombat : MonoBehaviour
{
    [SerializeField] private Transform AttackPoint;
    [SerializeField] private float AttackRange;
    [SerializeField] private int LightAttackDamage;
    [SerializeField] private int HeavyAttackDamage;
    [SerializeField] private GameObject Arrow;
    [SerializeField] private float XarrrowThrowSpeed;
    [SerializeField] private float YarrowThrowSpeed;
    [SerializeField] private int MaxHealth;
    [SerializeField] private int CurrentHelath;
    [SerializeField] private int PLADamage;
    [SerializeField] private int PHADamage;
    [SerializeField] private int PAADamage;

    private Animator PlayerAnimator;

    public HealthBar PlayerHealthBar;
    public LayerMask EnemyLayer;

    void Start()
    {
        PlayerAnimator = GetComponent<Animator>();
        CurrentHelath = MaxHealth;
        PlayerHealthBar.SetMaxHealth(MaxHealth);
    }

    void Update()
    {
        LightAttack();
        HeavyAttack();
        ArrowFire();
    }

    private void PlayerTakeDamage(int damage)
    {
        CurrentHelath -= damage;
        PlayerHealthBar.SetHealth(CurrentHelath);
        
        GetComponent<PlayerControl>().PlayerAlive(CurrentHelath);
        
        if (CurrentHelath <= 0)
        {
            enabled = false;
        }
    }

    public void AddHeal(int AddHealth)
    {
        CurrentHelath += AddHealth;
        PlayerHealthBar.SetHealth(CurrentHelath);
    }

    private void OnDrawGizmosSelected()
    {
        if (AttackPoint == null)
        {
            return;
        }
        Gizmos.DrawWireSphere(AttackPoint.position, AttackRange);
    }

    private void LightAttack()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Collider2D[] HitEnemies = Physics2D.OverlapCircleAll(AttackPoint.position, AttackRange, EnemyLayer);
            PlayerAnimator.SetTrigger("LightAttack");

            foreach(Collider2D enemy in HitEnemies)
            {
                enemy.GetComponent<EnemyTakeDamage>().TakeDamage(LightAttackDamage);
            }

            PlayerTakeDamage(PLADamage);
        }
    }

    private void HeavyAttack()
    {
        if (Input.GetMouseButtonDown(1))
        {
            Collider2D[] HitEnemies = Physics2D.OverlapCircleAll(AttackPoint.position, AttackRange, EnemyLayer);
            PlayerAnimator.SetTrigger("HeavyAttack");

            foreach (Collider2D enemy in HitEnemies)
            {
                enemy.GetComponent<EnemyTakeDamage>().TakeDamage(HeavyAttackDamage);
            }
            PlayerTakeDamage(PHADamage);
        }
    }

    private void ArrowFire()
    {
        if (Input.GetMouseButtonDown(4))
        {
            GameObject PlayerArrow = Instantiate(Arrow, transform.position, Quaternion.identity);
            PlayerArrow.transform.parent = GameObject.Find("Arrows").transform;

            if (transform.localScale.x > 0)
            {
                PlayerArrow.GetComponent<Rigidbody2D>().velocity = new Vector2(XarrrowThrowSpeed, YarrowThrowSpeed);
            }
            else
            {
                Vector3 PlayerArrowScale = PlayerArrow.transform.localScale;
                PlayerArrow.transform.localScale = new Vector3(-PlayerArrowScale.x, PlayerArrowScale.y, PlayerArrowScale.z);
                PlayerArrow.GetComponent<Rigidbody2D>().velocity = new Vector2(-XarrrowThrowSpeed, YarrowThrowSpeed);
            }
            PlayerTakeDamage(PAADamage);
        }        
    }
}

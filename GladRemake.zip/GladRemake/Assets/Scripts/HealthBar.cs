﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class HealthBar : MonoBehaviour
{
    public Slider PlayerSlider;
    public Image PlayerFill;
    public Gradient PlayerGradient;

    public void SetMaxHealth(int health)
    {
        PlayerSlider.maxValue = health;
        PlayerSlider.value = health;
        PlayerFill.color = PlayerGradient.Evaluate(1f);
    }

    public void SetHealth(int health)
    {
        PlayerSlider.value = health;
        PlayerFill.color = PlayerGradient.Evaluate(PlayerSlider.normalizedValue);
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class LevelManager : MonoBehaviour
{
    public void NextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        Time.timeScale = 1;
    }

    public void RestartLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        Time.timeScale = 1;
    }

    public void CloseLevel()
    {
        SceneManager.LoadScene(0);
    }

    public void TutorialScene()
    {
        SceneManager.LoadScene(3);
    }

    public void StartScene()
    {
        SceneManager.LoadScene(0);
    }

}

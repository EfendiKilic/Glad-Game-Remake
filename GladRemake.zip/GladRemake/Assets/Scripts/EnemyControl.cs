﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyControl : MonoBehaviour
{
    [SerializeField] private bool onGround;
    [SerializeField] LayerMask Ground;
    [SerializeField] private float RaycastLength;
    
    public float EnemySpeed;

    private float width;
    private Rigidbody2D EnemyRb;
    private Animator SkeletonAnimator;

    void Start()
    {
        EnemyRb = GetComponent<Rigidbody2D>();
        width = GetComponent<SpriteRenderer>().bounds.extents.x;
    }

    void Update()
    {
        if(this.gameObject.GetComponent<CapsuleCollider2D>().isActiveAndEnabled == true)
        {
            EnemyRayCast();
            Flip();
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Vector3 EnemyRealPosition = transform.position + (transform.right * (width / 2));
        Gizmos.DrawLine(EnemyRealPosition, EnemyRealPosition + new Vector3(0, -RaycastLength, 0));
    }

    private void EnemyRayCast()
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position + (transform.right * (width / 2)), Vector2.down, 2f, Ground);

        if(hit.collider != null)
        {
            onGround = true;
        }
        else
        {
            onGround = false;
        }
    }

    private void Flip()
    {
        if (!onGround)
        {
            transform.eulerAngles += new Vector3(0, 180f, 0);
        }
        EnemyRb.velocity = new Vector2(transform.right.x * EnemySpeed, 0f);

    }
}
